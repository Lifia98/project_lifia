<?php

class Report extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->library('PDFGenerator');
		$this->load->model("Aset_model");
	}

	public function aset()
	{
	    $data['arsip_aset'] = $this->Aset_model->getAll();

	    $template = $this->load->view('admin/reports/aset', $data, true);

	    $filename = 'laporan_aset'.date('Ymd_His');

	    $this->pdfgenerator->generate($template, $filename, true, 'A4', 'portrait');
	}
}