<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Aset extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("Aset_model");
		$this->load->library('form_validation');
		$this->load->model("user_model");
		if($this->user_model->isNotLogin()) redirect(site_url('admin/login'));
	}

	public function index()
	{
		$data["aset"] = $this->Aset_model->getAll();
		$this->load->view("admin/aset_list", $data);
	}

	public function add()
	{
		$aset = $this->Aset_model;
		$validation = $this->form_validation;
		$validation->set_rules($aset->rules());

		if ($validation->run()) {
			if ($aset->save()) {
				$this->session->set_flashdata('success','Berhasil disimpan');
				redirect('admin/aset');
			}
		}
		$this->load->view("admin/aset_add");
	}

	public function edit($id = null)
	{
		if (!isset($id)) redirect('admin/aset');

		$aset = $this->Aset_model;
		$validation = $this->form_validation;
		$validation->set_rules($aset->rules());

		if ($validation->run()) {
			if($aset->update($id)) {
				redirect('admin/aset');
			}
			$this->session->set_flashdata('success','Berhasil disimpan');
		}
		$data["aset"] = $aset->getById($id);
		if (!$data["aset"]) show_404();

		$this->load->view("admin/aset_update", $data);

	}

	public function delete($id=null)
	{
		if (!isset($id)) show_404();

		if ($this->Aset_model->delete($id)) {
			redirect(site_url('admin/aset'));
		}
	}
//--Kategori--//

	public function kategori()
	{
		$data["kategori"] = $this->Aset_model->getAll();
		$this->load->view("admin/kategori", $data);
	}

	public function addKategori()
	{
		$kategori = $this->Aset_model;
		$validation = $this->form_validation;
		$validation->set_rules($kategori->rules());

		if ($validation->run()) {
			if ($kategori->save()) {
				$this->session->set_flashdata('success','Berhasil disimpan');
				redirect('admin/kategori');
			}
		}
		$this->load->view("admin/kategori_add");
	}
	public function editKategori($id = null)
	{
		if (!isset($id)) redirect('admin/kategori');

		$kategori = $this->Aset_model;
		$validation = $this->form_validation;
		$validation->set_rules($kategori->rules());

		if ($validation->run()) {
			if($kategori->update($id)) {
				redirect('admin/kategori');
			}
			$this->session->set_flashdata('success','Berhasil disimpan');
		}
		$data["kategori"] = $kategori->getById($id);
		if (!$data["kategori"]) show_404();

		$this->load->view("admin/kategori_update", $data);

	}
	public function deleteKategori($id=null)
	{
		if (!isset($id)) show_404();

		if ($this->Aset_model->delete($id)) {
			redirect(site_url('admin/kategori'));
		}
	}
}
