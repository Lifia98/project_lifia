<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Aset_model extends CI_Model
{
	private $table = "aset";
	public $aset_id;
	public $kode;
	public $nama;
	public $kategori;
	public $ruangan;
	public $tanggal_inventaris;	
	public $batas_pemakaian;

	private $table ="kategori";
	public $kategori_id;
	public $nama_kategori;

	public function rules()
	{
		return [
			['field' => 'kode',
			'label' => 'Kode',
			'rules' => 'required'],

			['field' => 'nama',
			'label' => 'Nama',
			'rules' => 'required'],

			['field' => 'kategori',
			'label' => 'Kategori',
			'rules' => 'required'],

			['field' => 'ruangan',
			'label' => 'Ruangan',
			'rules' => 'required'],

			['field' => 'tanggal_inventaris',
			'label' => 'Tanggal Inventaris',
			'rules' => 'required'],

			['field' => 'batas_pemakaian',
			'label' => 'Batas Pemakaian',
			'rules' => 'required']
		];
	}

	public function getAll()
	{
		return $this->db->get($this->table)->result();
	}

	public function getById($id)
	{
		return $this->db->get_where($this->table, ["aset_id" => $id])->row();
	}

	public function save()
	{
		$post = $this->input->post();
		$this->aset_id = $post["aset_id"];
		$this->kode = $post["kode"];
		$this->nama = $post["nama"];
		$this->kategori = $post["kategori"];
		$this->ruangan = $post["ruangan"];
		$this->tanggal_inventaris = $post["tanggal_inventaris"];
		$this->batas_pemakaian = $post["batas_pemakaian"];
		return $this->db->insert($this->table, $this);
	}

	public function update($id)
	{
		$post = $this->input->post();
		$this->aset_id = $id;
		$this->kode = $post["kode"];
		$this->nama = $post["nama"];
		$this->kategori = $post["kategori"];
		$this->ruangan = $post["ruangan"];
		$this->tanggal_inventaris = $post["tanggal_inventaris"];
		$this->batas_pemakaian = $post["batas_pemakaian"];
		return $this->db->update($this->table, $this, array('aset_id' => $id));
	}

	public function delete($id)
	{
		return $this->db->delete($this->table, array('aset_id' => $id));
	}
}
//--Kategori--//
public function Kategori()
	{
		return [
			['field' => 'nama_kategori',
			'label' => 'nama_kategori',
			'rules' => 'required']
		];
	}

	public function getAllKategori()
	{
		return $this->db->get($this->table)->result();
	}

	public function getByIdKategori($id)
	{
		return $this->db->get_where($this->table, ["kategori_id" => $id])->row();
	}
	public function saveKategori()
	{
		$post = $this->input->post();
		$this->kategori_id = $post["kategori_id"];
		$this->nama_kategori = $post["nama_kategori"];	
		return $this->db->insert($this->table, $this);
	}

	public function updateKategori($id)
	{
		$post = $this->input->post();
		$this->kategori_id = $id;
		$this->nama_kategori = $post["nama_kategori"];
		return $this->db->update($this->table, $this, array('kategori_id' => $id));
	}

	public function deleteKategori($id)
	{
		return $this->db->delete($this->table, array('kategori_id' => $id));
	}
}