<table>
	<thead>
		<tr>
			<th>aset_id</th>
			<th>kode</th>
			<th>nama</th>
			<th>kategori</th>
			<th>ruangan</th>
			<th>tanggal_inventaris</th>
			<th>batas_pemakaian</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($arsip_aset as $data):?>
		<tr>
			<td><?php echo $data->aset_id;?></td>
			<td><?php echo $data->kode;?></td>
			<td><?php echo $data->nama;?></td>
			<td><?php echo $data->kategori;?></td>
			<td><?php echo $data->ruangan;?></td>
			<td><?php echo $data->tanggal_inventaris;?></td>
			<td><?php echo $data->batas_pemakaian;?></td>
		</tr>
		<?php endforeach;?>
	</tbody>
</table>




