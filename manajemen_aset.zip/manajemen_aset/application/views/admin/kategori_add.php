<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">
<?php $this->load->view("admin/_partials/navbar.php") ?>
<div id="wrapper">
	<?php $this->load->view("admin/_partials/sidebar.php") ?>
	<div class="container-fluid mt-3 mb-3">
		<?php $this->load->view("admin/_partials/breadcrumb.php") ?>

		<h2 class="mt-4 mb-4">List Kategori</h2>

		<?php if ($this->session->flashdata('success')): ?>
			<div class="alert alert-success" role="alert">
				<?php echo $this->session->flashdata('success'); ?>
			</div>
		<?php endif; ?>

		<div class="card mb-3">
			<div class="card-header">
				<a href="<?php echo site_url('admin/kategori') ?>"><i class="fas fa-arrow-left"></i> Kembali</a>
			</div>
			<div class="card-body">
				<form action="<?php echo site_url('admin/kategori/add') ?>" method="post" enctype="multipart/form-data">
					 
					<input type="hidden" name="kategori_id" value="<?php echo rand(10000000000,99999999999);?>" /> 
					<div class="form-group">
						<label for="kode">Nama Kategori</label>
						<input class="form-control <?php echo form_error('kode') ? 'is-invalid': '' ?>" type="text" name="nama_kategori" placeholder=" Kategori aset" /> 
						<div class="invalid-feedback">
							<?php echo form_error('nama_kategori') ?>
						</div>
					</div>
				<input class="btn btn-success" type="submit" name="btn" value="save" />
			</form>
		</div>

		<div class="card-footer small text-muted">
			= required fields
		</div>

	</div>
	<?php $this->load->view("admin/_partials/footer.php") ?>
</div>
<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
</body>
</html>