<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">
<?php $this->load->view("admin/_partials/navbar.php") ?>
<div id="wrapper">
	<?php $this->load->view("admin/_partials/sidebar.php") ?>
	<div class="container-fluid mt-3 mb-3">
		<?php $this->load->view("admin/_partials/breadcrumb.php") ?>

		<h2 class="mt-4 mb-4">Judul Halaman</h2>

		<?php if ($this->session->flashdata('success')): ?>
			<div class="alert alert-success" role="alert">
				<?php echo $this->session->flashdata('success'); ?>
			</div>
		<?php endif; ?>

		<div class="card mb-3">
			<div class="card-header">
				<a href="<?php echo site_url('admin/aset') ?>"><i class="fas fa-arrow-left"></i> Kembali</a>
			</div>
			<div class="card-body">
				<form action="<?php echo site_url('admin/aset/add') ?>" method="post" enctype="multipart/form-data">
					 
					<input type="hidden" name="aset_id" value="<?php echo rand(10000000000,99999999999);?>" /> 
					<div class="form-group">
						<label for="kode">Kode</label>
						<input class="form-control <?php echo form_error('kode') ? 'is-invalid': '' ?>" type="text" name="kode" placeholder=" kode aset" /> 
						<div class="invalid-feedback">
							<?php echo form_error('kode') ?>
						</div>
					</div>
					<div class="form-group">
						<label for="nama">Nama</label>
						<input class="form-control <?php echo form_error('nama') ? 'is-invalid': '' ?>" type="text" name="nama" placeholder=" nama aset" /> 
						<div class="invalid-feedback">
							<?php echo form_error('nama') ?>
						</div>
					</div>
					<div class="form-group">
						<label for="kategori">Kategori</label>
						<input class="form-control <?php echo form_error('kategori') ? 'is-invalid': '' ?>" type="text" name="kategori" placeholder=" kategori aset" /> 
						<div class="invalid-feedback">
							<?php echo form_error('kategori') ?>
						</div>
					</div>
					<div class="form-group">
						<label for="ruangan">Ruangan</label>
						<input class="form-control <?php echo form_error('ruangan') ? 'is-invalid': '' ?>" type="text" name="ruangan" placeholder=" ruangan aset" /> 
						<div class="invalid-feedback">
							<?php echo form_error('ruangan') ?>
						</div>
					</div>
					<div class="form-group">
						<label for="tanggal inventaris">Tanggal Inventaris</label>
						<input class="form-control <?php echo form_error('tanggal_inventaris') ? 'is-invalid': '' ?>" type="text" name="tanggal_inventaris" placeholder=" tanggal inventaris aset" /> 
						<div class="invalid-feedback">
							<?php echo form_error('tanggal inventaris') ?>
						</div>
					</div>
						<div class="form-group">
						<label for="batas pemakaian">Batas Pemakaian</label>
						<input class="form-control <?php echo form_error('batas_pemakaian') ? 'is-invalid': '' ?>" type="text" name="batas_pemakaian" placeholder=" batas pemakaian aset" /> 
						<div class="invalid-feedback">
							<?php echo form_error('batas pemakaian') ?>
						</div>
					</div>
				<input class="btn btn-success" type="submit" name="btn" value="save" />
			</form>
		</div>

		<div class="card-footer small text-muted">
			= required fields
		</div>

	</div>
	<?php $this->load->view("admin/_partials/footer.php") ?>
</div>
<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
</body>
</html>