<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>
<body id="page-top">
<?php $this->load->view("admin/_partials/navbar.php") ?>
<div id="wrapper">
	<?php $this->load->view("admin/_partials/sidebar.php") ?>
	<div class="container-fluid mt-3 mb-3">
	<center><h4>Welcome To Aplication Management Asset <b>PT. Radio Manggala Mediatama</b></h4></center>
	<center><img src="<?php echo base_url('assets/images/1.jpg'); ?>" width="500" height="350"></center>
	<center><h3><b>LIFIA - 41160178- TI-2016-RPL-P1</h3></center>
		</div>
	<?php $this->load->view("admin/_partials/footer.php") ?>
</div>
<?php $this->load->view("admin/_partials/scrolltop.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
</body>
</html>