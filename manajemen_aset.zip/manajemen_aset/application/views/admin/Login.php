<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">

<div class="panel-heading"><i class='fa fa-user'></i>
&nbsp;FORM LOGIN PENGGUNA</div><!-- /.panel-heading -->
<div class="panel-body">
<div class="col-md-5 col-md-offset-3">
<div class="row">
<form role="form" action="<?php echo site_url().'/c_login/auth'?>" method="post"
autocomplete="on"/>
<fieldset>
	<?php echo $this->session->flashdata('msg'); ?>
<div class="form-group">
	<label>USERNAME</label>
	<input class="form-control" name="username" type="text" placeholder="Ketikkan Username Disini" required autofocus>
</div>
<div class="form-group">
	<label>PASSWORD</label>
	<input class="form-control" name="password" type="password" placeholder="Ketikkan Password Disini" required required />
</div>

<div class="form-group">
	<button type="submit" class="btn btn-primary">L O G I N</button>
	<button type="reset" class="btn btn-success">R E S E T</button>
	<button type="button" class="btn btn-danger" onclick="self.history.back()">B A T A L</button>
</div>
</fieldset>
</form>
</div>
</div>
</div>
</div>
</div>
</div>