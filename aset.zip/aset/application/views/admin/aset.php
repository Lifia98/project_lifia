<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("admin/partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("admin/partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("admin/partials/sidebar.php") ?>
		<div id="content-wrapper">
			<div class="container-fluid">
				<?php $this->load->view("admin/partials/breadcrumb.php") ?>

<!-- DataTables -->
<div class="card mb-3">
	<div class="card-header">
		<a href="<?php echo site_url('admin/aset/add') ?>"><i class="fas fa-plus"></i>Add New</a>
	</div>
	<div class="card-body">
	<div class="table-responsive">
		<table class="table table-hover" id="dataTable" width="100%" collspacing="0">
			<thead>
				<tr>
					<th>Kode</th>
					<th>Nama</th>
					<th>Kategori</th>
					<th>Ruangan</th>
					<th>Tanggal Inventaris</th>
					<th>Batas Pemakaian</th>
					<th>Tombol Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($aset as $aset): ?> 
					<tr>
						<td width="150">
							<?php echo $aset->kode ?>
						</td>
						<td>
							<?php echo $aset->nama ?>
						</td>
						<td>
							<?php echo $aset->kategori ?>
						</td>
						<td>
							<?php echo $aset->ruangan ?>
						</td>
						<td>
							<?php echo $aset->tanggal inventaris?>
						</td>
						<td>
							<?php echo $aset->batas pemakaian ?>
						</td>
						<td width="250">
						<a href="<?php echo site_url('admin/aset/edit/'.$aset->aset_id) ?>" 
							<i class="btn btn-small"><i class="fas fa-edit"></i> Edit</a><a onclick="deleteConfirm('<?php echo site_url('admin/aset/delete/'.$aset->aset_id) ?>')" href="#!" class="btn btn-small text-danger"><i class="fas fa-trash"></i> Hapus</a>
							</td>
					</tr>
					<?php foreach; ?>
				</tbody>
			</table>

</div>
<!-- /.container-fluid -->

<!-- Sticky Footer -->
<?php $this->load->view("admin/partials/footer.php") ?>
</div>
<!-- /#wrapper -->

<?php $this->load->view("admin/partials/scrolltop.php") ?>
<?php $this->load->view("admin/partials/modal.php") ?>

<?php $this->load->view("admin/partials/js.php") ?>

</body>
</html>








			  