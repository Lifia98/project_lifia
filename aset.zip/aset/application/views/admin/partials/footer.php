<!-- Sticky Footer -->
<footer class="Sticky-footer">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright &copy <? echo SITE_NAME. " ". Date('Y') ?></span>
		</div>
	</div>
</footer>